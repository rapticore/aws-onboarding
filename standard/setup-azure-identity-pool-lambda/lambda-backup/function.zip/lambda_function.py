import json
import os
import time
import urllib.request
import boto3
from botocore.exceptions import ClientError

def lambda_handler(event, context):
    print('Lambda function started')
    print(f'Received event: {json.dumps(event)}')
    try:   
        if event['RequestType'] in ['Create', 'Update']:
            try:
        
                cognito_client = boto3.client(
                    'cognito-identity',
                    region_name=os.environ.get('AWS_REGION', 'us-west-2')
                )
                
                login_key = event['ResourceProperties']['LoginKey'] or 'standardazuredev1'
                login_value = event['ResourceProperties']['LoginValue'] or 'standardazuredev1.ore.rapticore.cloud'
                
                print(f"Using IdentityPoolId: {event['ResourceProperties']['IdentityPoolId']}")
                print(f"Using login: {login_key}:{login_value}")
                
                params = {
                    'IdentityPoolId': event['ResourceProperties']['IdentityPoolId'] or 'us-west-2:ca95a57e-0b93-4481-95b0-a918efecd71a',
                    'Logins': {
                        login_key: login_value
                    }
                }
                
           
                print(f'Calling get_open_id_token_for_developer_identity with params: {json.dumps(params)}')
                
              
                response = cognito_client.get_open_id_token_for_developer_identity(**params)
                
                print(f'Received response from Cognito: {json.dumps(response, default=str)}')
                
              
                serializable_response = json.loads(json.dumps(response, default=str))
                
            
                send_response(event, context, 'SUCCESS', serializable_response)
                return response
                
            except Exception as error:
                
                print(f'Error during processing: {str(error)}')
                
             
                send_response(event, context, 'FAILED', {'Error': str(error)})
                return
                
      
        elif event['RequestType'] == 'Delete':
            print('Processing Delete request')
            send_response(event, context, 'SUCCESS', {})
            return
            
    except Exception as outer_error:
      
        print(f'Unexpected error in Lambda handler: {str(outer_error)}')
        send_response(event, context, 'FAILED', {'Error': f'Unexpected error: {str(outer_error)}'})
        return

def send_response(event, context, response_status, response_data):
  
    print(f'Sending {response_status} response to CloudFormation')
    
  
    response_body = json.dumps({
        'Status': response_status,
        'Reason': f'Error: {response_data.get("Error")}' if response_status == 'FAILED' else f'See details in CloudWatch Log Stream: {context.log_stream_name}',
        'PhysicalResourceId': response_data.get('IdentityId', context.log_stream_name),
        'StackId': event['StackId'],
        'RequestId': event['RequestId'],
        'LogicalResourceId': event['LogicalResourceId'],
        'NoEcho': False,
        'Data': response_data
    })
    
  
    print(f'Response body: {response_body}')
    
  
    headers = {
        'content-type': '',  
        'content-length': str(len(response_body))
    }
    
    print(f'Sending response to URL: {event["ResponseURL"]}')
    
    try:
        print(f"Creating request object for URL: {event['ResponseURL']}")
        req = urllib.request.Request(
            url=event['ResponseURL'],
            data=response_body.encode('utf-8'),
            headers=headers,
            method='PUT'
        )
        print("Request object created successfully")
    
        try:
            print("Attempting to open URL connection...")
            with urllib.request.urlopen(req) as response:
                print(f"Connection opened, status code: {response.status}")
                response_data = response.read().decode('utf-8')
                if response_data:
                    print(f'Response data from CloudFormation: {response_data}')
            print('Successfully sent response to CloudFormation')
        except urllib.error.URLError as url_error:
            print(f"URLError when connecting: {url_error}")
            print(f"URLError reason: {url_error.reason}")
        except Exception as inner_error:
            print(f"Error during URL connection: {str(inner_error)}")
            print(f"Error type: {type(inner_error).__name__}")
            import traceback
            print("Traceback:", traceback.format_exc())
        
    except Exception as outer_error:
        print(f"Error creating request: {str(outer_error)}")
        print(f"Error type: {type(outer_error).__name__}")
        import traceback
        print("Traceback:", traceback.format_exc())